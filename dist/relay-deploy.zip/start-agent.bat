@echo off
setlocal

REM Pre-filled launcher. Tokens and URL already set below.
REM Just double-click. Pure ASCII, CRLF.

set "RELAY_URL=http://zhichuang-sr.com/relay/relay.jsp"
set "AGENT_TOKEN=PQJdAndLqiphWhxh3n2acj4f6Ft_dY5lt28zKPme6NT1RssUmuc-tyDm5MryyGKD"

cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0agent.ps1"

pause
endlocal
