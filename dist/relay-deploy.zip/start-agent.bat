@echo off
setlocal

REM Pre-filled launcher (v3, GitHub-based, no server needed).
REM Just double-click. Pure ASCII, CRLF.

cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0agent.ps1"

pause
endlocal
